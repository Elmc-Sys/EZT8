/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#define PIN_SPI_SS     (10)
#define PIN_SPI_MOSI   (11)
#define PIN_SPI_MISO   (12)
#define PIN_SPI_SCK    (13)
static const uint8_t SS   = PIN_SPI_SS;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;

#define digitalPinHasPWM(p)       ((p) == 2 ||(p) == 3 || (p) == 5 )
#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))
#define digitalPinToPCICR(p)      (((p) >= 0 && (p) <= 23) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p)   (((p) <= 7) ? 2 : (((p) <= 13) ? 0 : 1))
#define digitalPinToPCMSK(p)      (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 23) ? (&PCMSK1) : ((uint8_t *)0))))
#define digitalPinToPCMSKbit(p)   (((p) <= 7) ? (p) : (((p) <= 13) ? ((p) - 8) : ((p) - 14)))

#define PIN_IP1   (8)
#define PIN_IP2   (9)
#define PIN_IP3   (10)
#define PIN_IP4   (11)
#define PIN_IP5   (12)
#define PIN_IP6   (13)
#define PIN_IP7   (14)
#define PIN_IP8   (15)
#define PIN_OP1   (16)
#define PIN_OP2   (17)
#define PIN_OP3   (18)
#define PIN_OP4   (19)
#define PIN_OP5   (7)
#define PIN_OP6   (2)
#define PIN_OP7   (3)
#define PIN_OP8   (5)
#define PIN_ADC1  (21)	
#define PIN_ADC2  (20)	

static const uint8_t IP1 = PIN_IP1;
static const uint8_t IP2 = PIN_IP2;
static const uint8_t IP3 = PIN_IP3;
static const uint8_t IP4 = PIN_IP4;
static const uint8_t IP5 = PIN_IP5;
static const uint8_t IP6 = PIN_IP6;
static const uint8_t IP7 = PIN_IP7;
static const uint8_t IP8 = PIN_IP8;
static const uint8_t OP1 = PIN_OP1;
static const uint8_t OP2 = PIN_OP2;
static const uint8_t OP3 = PIN_OP3;
static const uint8_t OP4 = PIN_OP4;
static const uint8_t OP5 = PIN_OP5;
static const uint8_t OP6 = PIN_OP6;
static const uint8_t OP7 = PIN_OP7;
static const uint8_t OP8 = PIN_OP8;
static const uint8_t ADC1 = PIN_ADC1;
static const uint8_t ADC2 = PIN_ADC2;

#ifdef ARDUINO_MAIN

const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
	(uint16_t) &DDRE,
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
	(uint16_t) &PORTE,
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
	(uint16_t) &PINE,
};

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	PD,		
	PD,		
	PD,		
	PD,			
	PD,		
	PD,		
	PD,		
	PD,		
	PB, 	
	PB,		
	PB,		
	PB,		
	PB,		
	PB,		
	PC,		
	PC,		
	PC,		
	PC,		
	PC,		
	PC,		
	PE, 
	PE,
	PE,
	PE,	
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	_BV(0), 
	_BV(1), 
	_BV(2), 
	_BV(3), 
	_BV(4), 
	_BV(5), 
	_BV(6), 
	_BV(7), 
	_BV(0), 
	_BV(1), 
	_BV(2), 
	_BV(3), 
	_BV(4), 
	_BV(5), 
	_BV(0), 
	_BV(1), 
	_BV(2), 
	_BV(3), 
	_BV(4), 
	_BV(5), 
	_BV(2), 
	_BV(3),
	_BV(0),
	_BV(1),	
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
    TIMER3A,      
	TIMER4A,      
	TIMER4B,     
	TIMER2B,      
	NOT_ON_TIMER, 
	TIMER0B,    
	TIMER0A,    
	NOT_ON_TIMER,
	NOT_ON_TIMER, 
	TIMER1A,     
	TIMER1B,     
	TIMER2A,    
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
	NOT_ON_TIMER, 
};

#endif
#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial
#endif
