/*
  pins_arduino.h - Pin definition functions for Arduino
  Part of Arduino - http://www.arduino.cc/

  Copyright (c) 2007 David A. Mellis

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General
  Public License along with this library; if not, write to the
  Free Software Foundation, Inc., 59 Temple Place, Suite 330,
  Boston, MA  02111-1307  USA
*/

#ifndef Pins_Arduino_h
#define Pins_Arduino_h

#include <avr/pgmspace.h>

#if defined(__AVR_ATmega328PB__)
# define NUM_DIGITAL_PINS           24
# define NUM_ANALOG_INPUTS          8
# define analogInputToDigitalPin(p) ((p < 8) ? (p) + 14 : -1)
#else
# define NUM_DIGITAL_PINS           20
# define NUM_ANALOG_INPUTS          8
# define analogInputToDigitalPin(p) ((p < 6) ? (p) + 14 : -1)
#endif

#if defined(__AVR_ATmega328PB__)
# define digitalPinHasPWM(p)        ((p) == 0 || (p) == 1 || (p) == 2 || (p) == 3 || (p) == 5 || (p) == 6 || (p) == 9 || (p) == 10 || (p) == 11)
#elif defined(__AVR_ATmega8__)
# define digitalPinHasPWM(p)        ((p) == 9 || (p) == 10 || (p) == 11)
#else
# define digitalPinHasPWM(p)        ((p) == 3 || (p) == 5 || (p) == 6 || (p) == 9 || (p) == 10 || (p) == 11)
#endif

#define PIN_SPI_SS     (10)
#define PIN_SPI_MOSI   (11)
#define PIN_SPI_MISO   (12)
#define PIN_SPI_SCK    (13)

static const uint8_t SS   = PIN_SPI_SS;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK  = PIN_SPI_SCK;

#define PIN_WIRE_SDA   (18)
#define PIN_WIRE_SCL   (19)

static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

#if defined(__AVR_ATmega328PB__)
#define PIN_SPI1_SS    (20)
#define PIN_SPI1_MOSI  (21)
#define PIN_SPI1_MISO  (14)
#define PIN_SPI1_SCK   (15)

static const uint8_t SS1   = PIN_SPI1_SS;
static const uint8_t MOSI1 = PIN_SPI1_MOSI;
static const uint8_t MISO1 = PIN_SPI1_MISO;
static const uint8_t SCK1  = PIN_SPI1_SCK;

#define PIN_WIRE1_SDA   (22)
#define PIN_WIRE1_SCL   (23)

static const uint8_t SDA1 = PIN_WIRE1_SDA;
static const uint8_t SCL1 = PIN_WIRE1_SCL;
#endif

#define LED_BUILTIN 13

#define PIN_A0   (14)
#define PIN_A1   (15)
#define PIN_A2   (16)
#define PIN_A3   (17)
#define PIN_A4   (18)
#define PIN_A5   (19)
#define PIN_A6   (20)
#define PIN_A7   (21)

static const uint8_t A0 = PIN_A0;
static const uint8_t A1 = PIN_A1;
static const uint8_t A2 = PIN_A2;
static const uint8_t A3 = PIN_A3;
static const uint8_t A4 = PIN_A4;
static const uint8_t A5 = PIN_A5;
static const uint8_t A6 = PIN_A6;
static const uint8_t A7 = PIN_A7;

#define digitalPinToPCICR(p)    (((p) >= 0 && (p) <= 23) ? (&PCICR) : ((uint8_t *)0))
#define digitalPinToPCICRbit(p) (((p) <= 7) ? 2 : (((p) <= 13) ? 0 : 1))
#define digitalPinToPCMSK(p)    (((p) <= 7) ? (&PCMSK2) : (((p) <= 13) ? (&PCMSK0) : (((p) <= 23) ? (&PCMSK1) : ((uint8_t *)0))))
#define digitalPinToPCMSKbit(p) (((p) <= 7) ? (p) : (((p) <= 13) ? ((p) - 8) : ((p) - 14)))

#define digitalPinToInterrupt(p)  ((p) == 2 ? 0 : ((p) == 3 ? 1 : NOT_AN_INTERRUPT))

#define PIN_IP1   (8)
#define PIN_IP2   (9)
#define PIN_IP3   (10)
#define PIN_IP4   (11)
#define PIN_IP5   (12)
#define PIN_IP6   (13)
#define PIN_IP7   (14)
#define PIN_IP8   (15)
#define PIN_OP1   (16)
#define PIN_OP2   (17)
#define PIN_OP3   (18)
#define PIN_OP4   (19)
#define PIN_OP5   (7)
#define PIN_OP6   (2)
#define PIN_OP7   (3)
#define PIN_OP8   (5)
#define PIN_ADC1  (21)	
#define PIN_ADC2  (20)	

static const uint8_t IP1 = PIN_IP1;
static const uint8_t IP2 = PIN_IP2;
static const uint8_t IP3 = PIN_IP3;
static const uint8_t IP4 = PIN_IP4;
static const uint8_t IP5 = PIN_IP5;
static const uint8_t IP6 = PIN_IP6;
static const uint8_t IP7 = PIN_IP7;
static const uint8_t IP8 = PIN_IP8;
static const uint8_t OP1 = PIN_OP1;
static const uint8_t OP2 = PIN_OP2;
static const uint8_t OP3 = PIN_OP3;
static const uint8_t OP4 = PIN_OP4;
static const uint8_t OP5 = PIN_OP5;
static const uint8_t OP6 = PIN_OP6;
static const uint8_t OP7 = PIN_OP7;
static const uint8_t OP8 = PIN_OP8;
static const uint8_t ADC1 = PIN_ADC1;
static const uint8_t ADC2 = PIN_ADC2;

#ifdef ARDUINO_MAIN

// these arrays map port names (e.g. port B) to the
// appropriate addresses for various functions (e.g. reading
// and writing)
const uint16_t PROGMEM port_to_mode_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &DDRB,
	(uint16_t) &DDRC,
	(uint16_t) &DDRD,
#if defined(__AVR_ATmega328PB__)
	(uint16_t) &DDRE,
#endif
};

const uint16_t PROGMEM port_to_output_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PORTB,
	(uint16_t) &PORTC,
	(uint16_t) &PORTD,
#if defined(__AVR_ATmega328PB__)
	(uint16_t) &PORTE,
#endif
};

const uint16_t PROGMEM port_to_input_PGM[] = {
	NOT_A_PORT,
	NOT_A_PORT,
	(uint16_t) &PINB,
	(uint16_t) &PINC,
	(uint16_t) &PIND,
#if defined(__AVR_ATmega328PB__)
	(uint16_t) &PINE,
#endif
};

// ATmega328PB / Arduino
//
// 				    OP6	   TX    RX    RST   OP4   OP3   OP2   OP1
//				    PD2    PD1   PD0   PC6   PC5   PC4   PC3   PC2	
//				    (2)    (1)   (0)   (22)  (19)  (18)  (17)  (16)	
//					 32	    31    30    29    28    27    26    25
//				    ____   ____  ____  ____  ____  ____  ____  ____ 
//				   *										 	  *		
// OP7	PD3	 (3)  1|											  |24  15)  PC1 IP8
//		PD4	 (4)  2|											  |23 (14)  PC0 IP7
//		PE0	 (23) 3|											  |22 (26)  PE3  (ADC2)
//		VCC	      4|											  |21		GND
//		GND	      5|											  |20		AREF
//		PE1	 (24) 6|										      |19 (25)  PE2  (ADC1)
//		PB6	 (20) 7|X1									          |18		AVCC		
//		PB7	 (21) 8|X2									 	   SCK|17 (13)  PB5 IP6 
//				   *____  ____  ____  ____  ____  ____  ____  ____*		
//					 9    10    11    12    13     14    15    16	
//				    (5)   (6)   (7)   (8)   (9)   (10)  (11)  (12)
//				    PD5   PD6   PD7   PB0   PB1    PB2   PB3   PB4		
//				    OP8		    OP5   IP1   IP2    IP3   IP4   IP5
//													     MOSI  MISO
//

const uint8_t PROGMEM digital_pin_to_port_PGM[] = {
	PD,		//PD0 - D0
	PD,		//PD1 - D1
	PD,		//PD2 - D2	
	PD,		//PD3 - D3	
	PD,		//PD4 - D4	
	PD,		//PD5 - D5	
	PD,		//PD6 - D6
	PD,		//PD7 - D7
	PB, 	//PB0 - D8
	PB,		//PB1 - D9
	PB,		//PB2 - D10
	PB,		//PB3 - D11
	PB,		//PB4 - D12
	PB,		//PB5 - D13
	PC,		//PC0 - D14
	PC,		//PC1 - D15
	PC,		//PC2 - D16
	PC,		//PC3 - D17
	PC,		//PC4 - D18
	PC,		//PC5 - D19
	PB, 	//PB6 - D20 / XTAL1
	PB, 	//PB7 - D21 / XTAL2
	PC, 	//PC6 - D22 / RESET	
#if defined(__AVR_ATmega328PB__)
	PE, 	//PE0 - D23
	PE,		//PE1 - D24
	PE,		//PE2 - D25	/ A6
	PE,		//PE3 - D26	/ A7	
#endif
};

const uint8_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
	_BV(0), // PD0 - D0
	_BV(1), // PD1 - D1
	_BV(2), // PD2 - D2
	_BV(3), // PD3 - D3
	_BV(4), // PD4 - D4
	_BV(5), // PD5 - D5
	_BV(6), // PD6 - D6
	_BV(7), // PD7 - D7
	_BV(0), // PB0 - D8
	_BV(1), // PB1 - D9
	_BV(2), // PB2 - D10
	_BV(3), // PB3 - D11
	_BV(4), // PB4 - D12
	_BV(5), // PB5 - D13
	_BV(0), // PC0 - D14 
	_BV(1), // PC1 - D15
	_BV(2), // PC2 - D16
	_BV(3), // PC3 - D17 
	_BV(4), // PC4 - D18 
	_BV(5), // PC5 - D19 
	_BV(6), // PB6 - D20 / XTAL1
	_BV(7), // PB7 - D21 / XTAL2
	_BV(6), // PC6 - D22 / RESET
#if defined(__AVR_ATmega328PB__)
	_BV(0), // PE0 - D23
	_BV(1), // PE1 - D24
	_BV(2), // PE2 - D25 / A6
	_BV(3), // PE3 - D26 / A7
#endif
};

const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
#if defined(__AVR_ATmega328PB__)
	TIMER3A,        /* 0 - port D */
	TIMER4A,
	TIMER4B, // TIMER3B or TIMER4B
#else
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
#endif
	// on the ATmega168, digital pin 3 has hardware pwm
#if defined(__AVR_ATmega8__)
	NOT_ON_TIMER,
#else
	TIMER2B,
#endif
	NOT_ON_TIMER,
	// on the ATmega168, digital pins 5 and 6 have hardware pwm
#if defined(__AVR_ATmega8__)
	NOT_ON_TIMER,
	NOT_ON_TIMER,
#else
	TIMER0B,
	TIMER0A,
#endif
	NOT_ON_TIMER,
	NOT_ON_TIMER,   /* 8 - port B */
	TIMER1A,
	TIMER1B,
#if defined(__AVR_ATmega8__)
	TIMER2,
#else
	TIMER2A,
#endif
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,   /* 14 - port C */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
#if defined(__AVR_ATmega328PB__)
	NOT_ON_TIMER,   /* 20 - port E */
	NOT_ON_TIMER,
	NOT_ON_TIMER,
	NOT_ON_TIMER,
#endif
};

#endif

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_MONITOR   Serial
#define SERIAL_PORT_HARDWARE  Serial

#endif
